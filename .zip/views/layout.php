<?php
$user = require_login();
$allowed = [
    'dashboard' => ['Tenant', 'Staff', 'Admin', 'Technician'],
    'rooms' => ['Staff', 'Admin'],
    'tenants' => ['Admin'],
    'users' => ['Admin'],
    'meters' => ['Staff', 'Admin'],
    'payments' => ['Tenant', 'Staff', 'Admin'],
    'repairs' => ['Tenant', 'Staff', 'Admin', 'Technician'],
    'news' => ['Tenant', 'Staff', 'Admin', 'Technician'],
    'help' => ['Tenant', 'Staff', 'Admin', 'Technician'],
    'reports' => ['Staff', 'Admin'],
    'profile' => ['Tenant', 'Staff', 'Admin', 'Technician'],
];
if (!isset($allowed[$page]) || !in_array($user['role'], $allowed[$page], true)) {
    http_response_code(403);
    $page = 'dashboard';
}

$menuIcons = [
    'dashboard' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
    'rooms' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/><path d="M9 9v.01"/><path d="M9 12v.01"/><path d="M9 15v.01"/><path d="M9 18v.01"/></svg>',
    'tenants' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    'users' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><circle cx="12" cy="10" r="3"/><path d="M7 18.5a5 5 0 0 1 10 0"/></svg>',
    'meters' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
    'payments' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/><line x1="6" y1="15" x2="10" y2="15"/></svg>',
    'repairs' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
    'news' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/><path d="M18 14h-8"/><path d="M15 18h-5"/><path d="M10 6h8v4h-8V6Z"/></svg>',
    'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    'reports' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    'profile' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
];

$menus = [
    ['dashboard', 'ภาพรวม', $menuIcons['dashboard'], ['Tenant', 'Staff', 'Admin', 'Technician']],
    ['rooms', 'ห้องพัก', $menuIcons['rooms'], ['Staff', 'Admin']],
    ['tenants', 'ผู้เช่าและสัญญา', $menuIcons['tenants'], ['Admin']],
    ['users', 'บัญชีผู้ใช้งาน', $menuIcons['users'], ['Admin']],
    ['meters', 'มิเตอร์', $menuIcons['meters'], ['Staff', 'Admin']],
    ['payments', 'การชำระเงิน', $menuIcons['payments'], ['Tenant', 'Admin']],
    ['repairs', 'งานซ่อม', $menuIcons['repairs'], ['Tenant', 'Staff', 'Admin', 'Technician']],
    ['news', 'ข่าวสาร', $menuIcons['news'], ['Tenant', 'Staff', 'Admin', 'Technician']],
    ['reports', 'รายงาน', $menuIcons['reports'], ['Staff', 'Admin']],
];
$tenantContract = null;
if ($user['role'] === 'Tenant') {
    $query = db()->prepare("SELECT c.contractId, c.roomId, c.startDate, c.endDate, c.deposit, r.roomNumber, r.rentalPrice FROM Contract c JOIN Room r ON r.roomId = c.roomId WHERE c.userId = ? AND c.status = 'ใช้งานอยู่' ORDER BY c.startDate DESC LIMIT 1");
    $query->execute([$user['userId']]);
    $tenantContract = $query->fetch() ?: null;
}
$title = page_title($page);
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> | <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="assets/css/app.css?v=<?= e((string) filemtime(__DIR__ . '/../assets/css/app.css')) ?>-v5">
  <script defer src="assets/js/app.js?v=<?= e((string) filemtime(__DIR__ . '/../assets/js/app.js')) ?>-v5"></script>
</head>
<body class="app-body">
<div class="sidebar-backdrop" data-sidebar-backdrop></div>
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-top">
      <a class="sidebar-brand" href="index.php">
        <span class="brand-mark small">
          <svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 15 16 6l11 9M9 14v11h14V14M7 28c3-2 5-2 9 0s6 2 9 0" /></svg>
        </span>
        <span class="brand-copy">
          <strong>ฟ้าใสเพลส</strong>
          <small>RESIDENTIAL · CHIANG MAI</small>
        </span>
      </a>
      <button class="sidebar-collapse-btn" type="button" data-sidebar-collapse aria-label="ย่อหรือขยายแถบเมนู" title="ย่อ/ขยายเมนู">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
      </button>
    </div>

    <div class="sidebar-scroll">
      <div class="sidebar-label">เมนูจัดการระบบ</div>
      <nav class="main-nav">
        <?php foreach ($menus as [$key, $label, $iconSvg, $roles]): if (!in_array($user['role'], $roles, true)) continue; ?>
          <a class="nav-link <?= $page === $key ? 'active' : '' ?>" href="index.php?page=<?= e($key) ?>" title="<?= e($label) ?>">
            <span class="nav-icon" aria-hidden="true"><?= $iconSvg ?></span>
            <span class="nav-text"><?= e($label) ?></span>
            <?php if ($key === 'payments' && $user['role'] === 'Admin'): ?><span class="nav-dot" title="มีรายการรอตรวจสอบ"></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      </nav>
    </div>

    <div class="sidebar-bottom">
      <a class="help-note <?= $page === 'help' ? 'active' : '' ?>" href="index.php?page=help" title="ศูนย์ช่วยเหลือ">
        <span class="help-orbit" aria-hidden="true"><?= $menuIcons['help'] ?></span>
        <div class="help-copy">
          <strong>ศูนย์ช่วยเหลือ</strong>
          <small>คำแนะนำและติดต่อผู้ดูแล</small>
        </div>
      </a>
      <a class="nav-link <?= $page === 'profile' ? 'active' : '' ?>" href="index.php?page=profile" title="ข้อมูลส่วนตัว">
        <span class="nav-icon" aria-hidden="true"><?= $menuIcons['profile'] ?></span>
        <span class="nav-text">ข้อมูลส่วนตัว</span>
      </a>
    </div>
  </aside>
  <main class="main-area">
    <header class="topbar">
      <button class="icon-button sidebar-toggle-btn" type="button" aria-label="เปิดหรือปิดแถบเมนู" title="เปิด/ปิดแถบเมนู" data-menu-toggle>
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
      </button>
      <div class="breadcrumb"><span>ฟ้าใสเพลส</span><span class="breadcrumb-divider">/</span><strong><?= e($title) ?></strong></div>
      <div class="topbar-actions"><span class="date-stamp"><?= e(thai_date(date('Y-m-d'))) ?></span><span class="avatar"><?= e(mb_substr($user['name'], 0, 1, 'UTF-8')) ?></span><div class="user-meta"><strong><?= e($user['name']) ?></strong><small><?= e($user['role']) ?></small></div><form method="post" action="index.php" class="logout-form" id="logout-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="logout"><button class="button danger" type="button" onclick="document.getElementById('logout-confirm-modal').showModal()"><span aria-hidden="true">↪</span>ออกจากระบบ</button></form></div>
    </header>
    <div class="content-wrap">
      <?php if ($flashMessage): ?><div class="alert <?= e($flashMessage['type']) ?>" data-alert><?= e($flashMessage['message']) ?><button type="button" aria-label="ปิด" data-dismiss>×</button></div><?php endif; ?>
      <?php if ($page === 'dashboard'): ?>
        <?php
        if ($user['role'] === 'Tenant') {
          $repairCountStatement = db()->prepare('SELECT COUNT(*) FROM Repair WHERE userId = ?');
          $repairCountStatement->execute([$user['userId']]);
            $metrics = [
                ['ห้องพักของฉัน', $tenantContract ? $tenantContract['roomNumber'] : 'ยังไม่มีสัญญา', '⌂', 'blue'],
                ['ค่าเช่ารายเดือน', $tenantContract ? money($tenantContract['rentalPrice']) . ' ฿' : '—', '฿', 'mint'],
            ['คำร้องแจ้งซ่อม', (string) $repairCountStatement->fetchColumn(), '⌕', 'orange'],
                ['สถานะสัญญา', $tenantContract ? 'ใช้งานอยู่' : 'ไม่มีสัญญา', '▣', 'blue'],
            ];
        } else {
            $roomCount = (int) db()->query('SELECT COUNT(*) FROM Room')->fetchColumn();
            $occupiedCount = (int) db()->query("SELECT COUNT(*) FROM Room WHERE roomStatus = 'มีผู้เช่า'")->fetchColumn();
            $openRepairs = (int) db()->query("SELECT COUNT(*) FROM Repair WHERE repairStatus NOT IN ('ซ่อมเสร็จแล้ว', 'ยกเลิก')")->fetchColumn();
            $pendingPayments = $user['role'] === 'Admin' ? (int) db()->query("SELECT COUNT(*) FROM Payment WHERE status = 'รอตรวจสอบ'")->fetchColumn() : 0;
            $metrics = [
                ['ห้องพักทั้งหมด', (string) $roomCount, '⌂', 'blue'],
                ['มีผู้เช่า', (string) $occupiedCount, '♙', 'mint'],
                ['งานซ่อมที่เปิดอยู่', (string) $openRepairs, '⌕', 'orange'],
                [$user['role'] === 'Admin' ? 'รอตรวจสอบการชำระ' : 'ห้องว่าง', $user['role'] === 'Admin' ? (string) $pendingPayments : (string) max(0, $roomCount - $occupiedCount), '฿', 'blue'],
            ];
        }
        ?>
        <section class="page-heading"><div><p class="eyebrow">FAH SAI PLACE / OVERVIEW</p><h1>สวัสดี, <?= e($user['name']) ?></h1><p class="muted">ภาพรวมการดำเนินงานหอพัก ณ วันนี้</p></div><?php if ($user['role'] === 'Admin'): ?><a class="button primary" href="index.php?page=rooms">จัดการห้องพัก <span>↗</span></a><?php endif; ?></section>
        <section class="overview-clock panel"><span class="clock-icon" aria-hidden="true">◷</span><div><small>เวลาปัจจุบัน · ประเทศไทย</small><strong data-digital-clock><?= e(date('H:i:s')) ?></strong></div><span class="clock-date"><?= e('วัน' . ['อาทิตย์','จันทร์','อังคาร','พุธ','พฤหัสบดี','ศุกร์','เสาร์'][date('w')] . ', ' . thai_date(date('Y-m-d'))) ?></span></section>
        <section class="metric-grid"><?php foreach ($metrics as [$label, $value, $icon, $color]): ?><article class="metric-card"><div class="metric-top"><span><?= e($label) ?></span><span class="metric-icon <?= e($color) ?>"><?= e($icon) ?></span></div><strong><?= e($value) ?></strong><small><?= $label === 'ค่าเช่ารายเดือน' ? 'บาทต่อเดือน' : 'ข้อมูลจากระบบปัจจุบัน' ?></small></article><?php endforeach; ?></section>
        <?php if ($user['role'] === 'Tenant' && $tenantContract): ?><section class="panel lease-summary"><div class="panel-heading"><div><p class="eyebrow">ACTIVE LEASE</p><h2>รายละเอียดสัญญาเช่า</h2></div><span class="status-pill available">ใช้งานอยู่</span></div><div class="lease-details"><div><small>เลขที่สัญญา</small><strong class="mono"><?= e($tenantContract['contractId']) ?></strong></div><div><small>ห้องพัก</small><strong><?= e($tenantContract['roomNumber']) ?></strong></div><div><small>ระยะเวลาสัญญา</small><strong><?= e(thai_date($tenantContract['startDate'])) ?> – <?= $tenantContract['endDate'] ? e(thai_date($tenantContract['endDate'])) : 'ไม่กำหนดวันสิ้นสุด' ?></strong></div><div><small>เงินประกัน</small><strong><?= money($tenantContract['deposit']) ?> ฿</strong></div></div></section><?php endif; ?>
        <section class="dashboard-grid">
          <article class="panel overview-panel"><div class="panel-heading"><div><p class="eyebrow">QUICK ACCESS</p><h2>รายการที่ใช้งานบ่อย</h2></div><span class="panel-caption">เลือกทำรายการ</span></div><div class="quick-grid">
          <?php foreach (array_filter($menus, fn($item) => in_array($user['role'], $item[3], true) && $item[0] !== 'dashboard') as [$key, $label, $iconSvg]): ?><a class="quick-link" href="index.php?page=<?= e($key) ?>"><span class="quick-icon" aria-hidden="true"><?= $iconSvg ?></span><span><strong><?= e($label) ?></strong><small>เปิดหน้าจัดการ</small></span><b>↗</b></a><?php endforeach; ?>
          </div></article>
          <article class="panel news-panel"><div class="panel-heading"><div><p class="eyebrow">NOTICE BOARD</p><h2>ประกาศล่าสุด</h2></div><a class="text-link" href="index.php?page=news">ดูทั้งหมด →</a></div><?php $latestNews = db()->query('SELECT * FROM News ORDER BY publishDate DESC LIMIT 3')->fetchAll(); if (!$latestNews): ?><div class="empty-state compact"><span>▤</span><strong>ยังไม่มีประกาศ</strong><small>ประกาศจากหอพักจะแสดงที่นี่</small></div><?php else: foreach ($latestNews as $item): ?><button class="news-item news-preview-trigger" type="button" data-news-preview="<?= e(json_encode($item, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>"><span class="news-date"><?= e(date('d M', strtotime($item['publishDate']))) ?></span><span><strong><?= e($item['title']) ?></strong><span class="news-summary"><?= e(mb_strimwidth($item['detail'], 0, 100, '...', 'UTF-8')) ?></span><?php if (!empty($item['image'])): ?><small class="news-image-hint">แตะเพื่อดูรูปประกาศ</small><?php endif; ?></span><span class="news-open" aria-hidden="true">↗</span></button><?php endforeach; endif; ?></article>
        </section>
      <?php elseif ($page === 'rooms'): ?>
        <?php $rooms = db()->query("SELECT r.*, c.userId AS activeTenantId, c.startDate AS activeStartDate, c.deposit AS activeDeposit, u.name AS activeTenantName FROM Room r LEFT JOIN Contract c ON c.contractId = (SELECT c2.contractId FROM Contract c2 WHERE c2.roomId = r.roomId AND c2.status = 'ใช้งานอยู่' ORDER BY c2.startDate DESC, c2.contractId DESC LIMIT 1) LEFT JOIN `User` u ON u.userId = c.userId ORDER BY r.roomNumber")->fetchAll(); $roomTenants = db()->query("SELECT u.userId, u.name, c.roomId AS activeRoomId FROM `User` u LEFT JOIN Contract c ON c.userId = u.userId AND c.status = 'ใช้งานอยู่' WHERE u.role = 'Tenant' ORDER BY u.name")->fetchAll(); ?>
        <section class="page-heading"><div><p class="eyebrow">ROOM DIRECTORY</p><h1>ห้องพัก</h1><p class="muted">จัดการสถานะห้องพักและอัตราค่าเช่า</p></div><?php if ($user['role'] === 'Admin'): ?><button class="button primary" type="button" data-modal-open="room-modal">＋ เพิ่มห้องพัก</button><?php endif; ?></section>
        <section class="panel table-panel"><div class="table-toolbar"><div class="search-box"><span>⌕</span><input type="search" placeholder="ค้นหาเลขห้อง..." data-table-search></div><span class="panel-caption"><?= count($rooms) ?> ห้อง</span></div><div class="table-scroll"><table><thead><tr><th>ห้อง</th><th>ผู้เช่าปัจจุบัน</th><th>สถานะ</th><th>ค่าเช่าต่อเดือน</th><th></th></tr></thead><tbody><?php foreach ($rooms as $room): ?><tr data-search-row><td><strong class="room-number"><?= e($room['roomNumber']) ?></strong></td><td><?= e($room['activeTenantName'] ?? '—') ?></td><td><span class="status-pill <?= $room['roomStatus'] === 'มีผู้เช่า' ? 'occupied' : ($room['roomStatus'] === 'ว่าง' ? 'available' : 'pending') ?>"><?= e($room['roomStatus']) ?></span></td><td><?= money($room['rentalPrice']) ?> ฿</td><td><?php if (in_array($user['role'], ['Staff', 'Admin'], true)): ?><button class="icon-button" type="button" data-room='<?= e(json_encode($room, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>' data-edit-room aria-label="แก้ไขห้องพัก">✎</button><?php endif; ?></td></tr><?php endforeach; ?></tbody></table><?php if (!$rooms): ?><div class="empty-state"><span>⌂</span><strong>ยังไม่มีข้อมูลห้องพัก</strong><small>เริ่มต้นเพิ่มห้องพักในระบบ</small></div><?php endif; ?></div></section>
        <?php if (in_array($user['role'], ['Staff', 'Admin'], true)): ?>
          <dialog class="modal" id="room-modal">
            <form method="post" action="index.php" class="modal-form">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="save_room">
              <input type="hidden" name="return_page" value="rooms">
              <input type="hidden" name="roomId">
              <div class="modal-heading"><div><p class="eyebrow">ROOM DETAILS</p><h2>ข้อมูลห้องพัก</h2></div><button class="icon-button" type="button" data-modal-close aria-label="ปิด">×</button></div>
              <label>เลขห้อง<input name="roomNumber" required maxlength="20" placeholder="เช่น 101"></label>
              <label>ค่าเช่าต่อเดือน<input name="rentalPrice" type="number" min="0" step="0.01" required></label>
              <label>สถานะห้อง<select name="roomStatus" data-room-status><option>ว่าง</option><option>มีผู้เช่า</option><option>ปิดปรับปรุง</option></select></label>
              <div class="room-assignment-fields" data-room-assignment-fields hidden>
                <label>ผู้เช่าที่ทำสัญญา<select name="tenantId" data-room-tenant><option value="">เลือกผู้เช่า</option><?php foreach ($roomTenants as $tenant): ?><option value="<?= e($tenant['userId']) ?>" data-active-room="<?= e($tenant['activeRoomId'] ?? '') ?>"><?= e($tenant['name']) ?></option><?php endforeach; ?></select></label>
                <div class="form-row">
                  <label>วันที่เริ่มสัญญา<input name="startDate" type="date" data-room-start></label>
                  <label>เงินประกัน<input name="deposit" type="number" min="0" step="0.01" value="0" data-room-deposit></label>
                </div>
                <p class="form-hint" data-room-assignment-note>เลือกผู้เช่าที่ยังไม่มีสัญญาใช้งานอยู่ และระบุวันที่เริ่มสัญญา</p>
              </div>
              <div class="modal-actions"><button class="button secondary" type="button" data-modal-close>ยกเลิก</button><button class="button primary" type="submit">บันทึกข้อมูล</button></div>
            </form>
          </dialog>
        <?php endif; ?>
      <?php elseif ($page === 'tenants'): ?>
        <?php $tenants = db()->query("SELECT u.userId, u.name, u.phone, u.email, c.contractId, c.startDate, c.endDate, c.status, r.roomNumber, r.rentalPrice FROM `User` u LEFT JOIN Contract c ON c.userId = u.userId AND c.status = 'ใช้งานอยู่' LEFT JOIN Room r ON r.roomId = c.roomId WHERE u.role = 'Tenant' ORDER BY u.name")->fetchAll(); $freeRooms = db()->query("SELECT roomId, roomNumber FROM Room WHERE roomStatus = 'ว่าง' ORDER BY roomNumber")->fetchAll(); ?>
        <section class="page-heading"><div><p class="eyebrow">RESIDENTS & LEASES</p><h1>ผู้เช่าและสัญญา</h1><p class="muted">ข้อมูลผู้เช่าปัจจุบันและสัญญาเช่า</p></div><button class="button primary" type="button" data-modal-open="tenant-modal">＋ เพิ่มผู้เช่า</button></section>
        <section class="panel table-panel"><div class="table-toolbar"><div class="search-box"><span>⌕</span><input type="search" placeholder="ค้นหาชื่อหรือห้อง..." data-table-search></div><span class="panel-caption"><?= count($tenants) ?> ราย</span></div><div class="table-scroll"><table><thead><tr><th>ผู้เช่า</th><th>ห้อง</th><th>เบอร์โทรศัพท์</th><th>ค่าเช่า</th><th>สิ้นสุดสัญญา</th><th>สถานะ</th><th>ดำเนินการ</th></tr></thead><tbody><?php foreach ($tenants as $tenant): ?><tr data-search-row><td><strong><?= e($tenant['name']) ?></strong><small class="table-sub"><?= e($tenant['email']) ?></small></td><td><?= e($tenant['roomNumber'] ?? 'ยังไม่กำหนด') ?></td><td><?= e($tenant['phone']) ?></td><td><?= $tenant['rentalPrice'] !== null ? money($tenant['rentalPrice']) . ' ฿' : '—' ?></td><td><?= $tenant['endDate'] ? e(thai_date($tenant['endDate'])) : '—' ?></td><td><span class="status-pill <?= $tenant['status'] ? 'available' : 'pending' ?>"><?= e($tenant['status'] ?? 'ไม่มีสัญญา') ?></span></td><td><?php if ($tenant['contractId']): ?><form method="post" action="index.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="end_contract"><input type="hidden" name="contractId" value="<?= e($tenant['contractId']) ?>"><input type="hidden" name="return_page" value="tenants"><button class="button tiny danger" type="submit" data-confirm="สิ้นสุดสัญญาและคืนห้องนี้เป็นห้องว่างหรือไม่?">สิ้นสุดสัญญา</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table><?php if (!$tenants): ?><div class="empty-state"><span>♙</span><strong>ยังไม่มีผู้เช่า</strong><small>เพิ่มผู้เช่าและสร้างสัญญาเช่ารายแรก</small></div><?php endif; ?></div></section>
        <?php $activeContracts = db()->query("SELECT c.contractId, c.startDate, c.endDate, u.name, r.roomNumber FROM Contract c JOIN `User` u ON u.userId = c.userId JOIN Room r ON r.roomId = c.roomId WHERE c.status = 'ใช้งานอยู่' ORDER BY r.roomNumber")->fetchAll(); ?>
        <section class="panel contract-edit-panel"><div class="panel-heading"><div><p class="eyebrow">LEASE DATES</p><h2>กำหนดวันสิ้นสุดสัญญา</h2></div><span class="panel-caption">เว้นว่างหากไม่กำหนดวันสิ้นสุด</span></div><?php if ($activeContracts): ?><div class="contract-edit-list"><?php foreach ($activeContracts as $contract): ?><form method="post" action="index.php" class="contract-edit-row"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_contract"><input type="hidden" name="return_page" value="tenants"><input type="hidden" name="contractId" value="<?= e($contract['contractId']) ?>"><div><strong><?= e($contract['name']) ?></strong><small>ห้อง <?= e($contract['roomNumber']) ?> · เริ่ม <?= e(thai_date($contract['startDate'])) ?></small></div><label>วันสิ้นสุด<input type="date" name="endDate" value="<?= e($contract['endDate']) ?>" min="<?= e($contract['startDate']) ?>"></label><button class="button tiny primary" type="submit">บันทึก</button></form><?php endforeach; ?></div><?php else: ?><div class="empty-state compact"><strong>ไม่มีสัญญาที่กำลังใช้งาน</strong></div><?php endif; ?></section>
        <dialog class="modal" id="tenant-modal"><form method="post" action="index.php" class="modal-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_tenant"><input type="hidden" name="return_page" value="tenants"><div class="modal-heading"><div><p class="eyebrow">NEW RESIDENT</p><h2>เพิ่มผู้เช่า</h2></div><button class="icon-button" type="button" data-modal-close aria-label="ปิด">×</button></div><div class="form-row"><label>ชื่อ-นามสกุล<input name="name" required maxlength="100"></label><label>Username<input name="username" required maxlength="50"></label></div><div class="form-row"><label>เบอร์โทรศัพท์<input name="phone" required pattern="[0-9]{10}" maxlength="10"></label><label>อีเมล<input type="email" name="email" required maxlength="100"></label></div><label>รหัสผ่านเริ่มต้น<input type="password" name="password" required minlength="10"></label><div class="form-row"><label>ห้องพัก<select name="roomId"><option value="">ยังไม่กำหนดห้อง</option><?php foreach ($freeRooms as $room): ?><option value="<?= e($room['roomId']) ?>"><?= e($room['roomNumber']) ?></option><?php endforeach; ?></select></label><label>วันที่เริ่มสัญญา<input type="date" name="startDate"></label></div><div class="form-row"><label>วันสิ้นสุดสัญญา<input type="date" name="endDate"></label><label>เงินประกัน<input type="number" name="deposit" min="0" step="0.01" value="0"></label></div><div class="modal-actions"><button class="button secondary" type="button" data-modal-close>ยกเลิก</button><button class="button primary" type="submit">สร้างข้อมูลผู้เช่า</button></div></form></dialog>
      <?php elseif ($page === 'users'): ?>
        <?php $accounts = db()->query("SELECT userId, username, name, phone, email, role FROM `User` ORDER BY role, name")->fetchAll(); ?>
        <section class="page-heading"><div><p class="eyebrow">ACCESS CONTROL</p><h1>บัญชีผู้ใช้งาน</h1><p class="muted">สร้างบัญชีและกำหนดบทบาทการเข้าใช้งาน</p></div><button class="button primary" type="button" data-modal-open="user-modal">＋ เพิ่มบัญชี</button></section>
        <section class="panel table-panel"><div class="table-toolbar"><div class="search-box"><span>⌕</span><input type="search" placeholder="ค้นหาชื่อหรือ Username..." data-table-search></div><span class="panel-caption"><?= count($accounts) ?> บัญชี</span></div><div class="table-scroll"><table><thead><tr><th>ชื่อผู้ใช้งาน</th><th>Username</th><th>เบอร์โทรศัพท์</th><th>อีเมล</th><th>บทบาท</th><th>ปรับสิทธิ์</th><th></th></tr></thead><tbody><?php foreach ($accounts as $account): ?><tr data-search-row><td><strong><?= e($account['name']) ?></strong></td><td class="mono"><?= e($account['username']) ?></td><td><?= e($account['phone']) ?></td><td><?= e($account['email']) ?></td><td><span class="status-pill <?= $account['role'] === 'Admin' ? 'occupied' : 'available' ?>"><?= e($account['role']) ?></span></td><td><form method="post" action="index.php" class="role-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_user_role"><input type="hidden" name="userId" value="<?= e($account['userId']) ?>"><input type="hidden" name="return_page" value="users"><select name="role"><option <?= $account['role'] === 'Tenant' ? 'selected' : '' ?>>Tenant</option><option <?= $account['role'] === 'Staff' ? 'selected' : '' ?>>Staff</option><option <?= $account['role'] === 'Technician' ? 'selected' : '' ?>>Technician</option><option <?= $account['role'] === 'Admin' ? 'selected' : '' ?>>Admin</option></select><button class="button tiny secondary" type="submit">บันทึก</button></form></td><td class="row-actions"><button class="icon-button" type="button" data-edit-account data-account="<?= e(json_encode($account, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>" aria-label="แก้ไขบัญชี">✎</button><?php if ($account['userId'] !== $user['userId']): ?><form method="post" action="index.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="userId" value="<?= e($account['userId']) ?>"><input type="hidden" name="return_page" value="users"><button class="icon-button danger-icon" type="submit" data-confirm="ลบบัญชีนี้หรือไม่?" aria-label="ลบบัญชี">×</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></section>
        <dialog class="modal account-modal" id="user-modal"><form method="post" action="index.php" class="modal-form account-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_user"><input type="hidden" name="userId"><input type="hidden" name="return_page" value="users">
          <div class="modal-heading"><div><p class="eyebrow">ACCOUNT DETAILS</p><h2>เพิ่มบัญชีผู้ใช้งาน</h2><p class="muted">กรอกข้อมูลให้ครบ แล้วกำหนดรหัสผ่านที่คาดเดายาก</p></div><button class="icon-button" type="button" data-modal-close aria-label="ปิด">×</button></div>
          <section class="account-section"><h3>ข้อมูลส่วนตัว</h3><div class="form-row"><label class="required-field"><span>ชื่อ-นามสกุล <span class="required-mark" aria-hidden="true">*</span></span><input name="name" maxlength="100" autocomplete="name" required></label><label class="required-field"><span>Username <span class="required-mark" aria-hidden="true">*</span></span><input name="username" maxlength="50" autocomplete="username" required></label></div>
            <div class="form-row"><label class="required-field"><span>เบอร์โทรศัพท์ <span class="required-mark" aria-hidden="true">*</span></span><input name="phone" type="tel" inputmode="numeric" pattern="[0-9]{10}" maxlength="10" autocomplete="tel" required></label><label class="required-field"><span>อีเมล <span class="required-mark" aria-hidden="true">*</span></span><input type="email" name="email" maxlength="100" autocomplete="email" required></label></div>
            <div class="form-row"><label class="required-field"><span>บทบาท <span class="required-mark" aria-hidden="true">*</span></span><select name="role" required><option>Tenant</option><option>Staff</option><option>Technician</option><option>Admin</option></select></label></div>
          </section>
          <section class="account-section password-section"><h3>ตั้งรหัสผ่าน</h3><p class="form-hint" data-password-note>รหัสผ่านใหม่ต้องผ่านเงื่อนไขครบทุกข้อ</p>
            <div class="form-row"><label class="password-label required-field"><span>รหัสผ่าน <span class="required-mark" aria-hidden="true">*</span></span><span class="password-control"><input type="password" name="password" minlength="12" autocomplete="new-password" data-password required><button class="password-toggle" type="button" data-toggle-password="password" aria-label="แสดงรหัสผ่าน">แสดง</button></span></label>
              <label class="password-label required-field"><span>ยืนยันรหัสผ่าน <span class="required-mark" aria-hidden="true">*</span></span><span class="password-control"><input type="password" name="password_confirm" minlength="12" autocomplete="new-password" data-password-confirm required><button class="password-toggle" type="button" data-toggle-password="password_confirm" aria-label="แสดงรหัสผ่านที่ยืนยัน">แสดง</button></span><small data-password-match aria-live="polite">กรอกรหัสผ่านอีกครั้งให้ตรงกัน</small></label>
            </div>
            <div class="password-strength"><div class="strength-heading"><strong>ความปลอดภัยของรหัสผ่าน</strong><span data-password-strength-label>ยังไม่ได้ตั้ง</span></div><div class="strength-track" data-password-strength role="progressbar" aria-label="ระดับความปลอดภัยของรหัสผ่าน" aria-valuemin="0" aria-valuemax="5" aria-valuenow="0"><span></span></div>
              <ul class="password-checklist"><li data-password-rule="length">อย่างน้อย 12 ตัวอักษร</li><li data-password-rule="lowercase">มีตัวพิมพ์เล็ก (a-z)</li><li data-password-rule="uppercase">มีตัวพิมพ์ใหญ่ (A-Z)</li><li data-password-rule="number">มีตัวเลข (0-9)</li><li data-password-rule="symbol">มีอักขระพิเศษ เช่น ! @ #</li></ul>
            </div>
          </section>
          <div class="modal-actions"><button class="button secondary" type="button" data-modal-close>ยกเลิก</button><button class="button primary" type="submit">สร้างบัญชี</button></div>
        </form></dialog>
      <?php elseif ($page === 'meters'): ?>
        <?php 
        $meters = db()->query('SELECT m.*, r.roomNumber FROM MeterRecord m JOIN Room r ON r.roomId = m.roomId ORDER BY m.recordDate DESC, r.roomNumber LIMIT 100')->fetchAll(); 
        $allRooms = db()->query('SELECT roomId, roomNumber FROM Room ORDER BY roomNumber')->fetchAll(); 
        $lastMeterRows = db()->query('SELECT roomId, month, waterUnit, electricUnit, recordDate FROM MeterRecord')->fetchAll(); 
        $lastMetersByRoom = []; 
        foreach ($lastMeterRows as $lastMeter) { 
            $monthIndex = billing_month_index((string) $lastMeter['month']); 
            $lastIndex = isset($lastMetersByRoom[$lastMeter['roomId']]) ? billing_month_index((string) $lastMetersByRoom[$lastMeter['roomId']]['month']) : null; 
            if ($monthIndex !== null && ($lastIndex === null || $monthIndex > $lastIndex)) { 
                $lastMetersByRoom[$lastMeter['roomId']] = $lastMeter; 
            } 
        } 
        ?>
        <section class="page-heading"><div><p class="eyebrow">UTILITY READINGS</p><h1>บันทึกมิเตอร์</h1><p class="muted">บันทึกหน่วยการใช้น้ำและไฟฟ้าประจำรอบเดือน</p></div></section>
        <section class="panel form-panel">
          <div class="panel-heading"><div><p class="eyebrow">NEW METER RECORD</p><h2>บันทึกการใช้สาธารณูปโภค</h2></div><span class="panel-caption">หน่วยที่ใช้ในรอบบิล</span></div>
          <form method="post" action="index.php" class="inline-form" data-meter-form>
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="save_meter">
            <input type="hidden" name="return_page" value="meters">
            <label>ห้องพัก<select name="roomId" required data-meter-room><option value="">เลือกห้อง</option><?php foreach ($allRooms as $room): $lastMeter = $lastMetersByRoom[$room['roomId']] ?? null; ?><option value="<?= e($room['roomId']) ?>" data-last-month="<?= e($lastMeter['month'] ?? '') ?>" data-last-water="<?= e((string) ($lastMeter['waterUnit'] ?? '')) ?>" data-last-electric="<?= e((string) ($lastMeter['electricUnit'] ?? '')) ?>" data-last-date="<?= $lastMeter ? e(thai_date($lastMeter['recordDate'])) : '' ?>"><?= e($room['roomNumber']) ?></option><?php endforeach; ?></select></label>
            <label>เดือน/ปี<input name="month" required maxlength="20" placeholder="เช่น 10/2569"></label>
            <label>หน่วยน้ำ<input type="number" min="0" step="0.01" name="waterUnit" required></label>
            <label>หน่วยไฟฟ้า<input type="number" min="0" step="0.01" name="electricUnit" required></label>
            <button class="button primary" type="submit">บันทึกมิเตอร์</button>
          </form>
          <p class="meter-previous" data-previous-meter aria-live="polite">เลือกห้องเพื่อดูบันทึกมิเตอร์ครั้งก่อน</p>
          <p class="form-hint">ระบบจะแสดงมิเตอร์งวดล่าสุดไว้ตรวจสอบก่อนบันทึกงวดใหม่ (ผู้ดูแลระบบสามารถแก้ไขหรือลบรายการที่ยังไม่ชำระเงินได้)</p>
        </section>
        <section class="panel table-panel">
          <div class="panel-heading" style="padding: 20px 24px 12px;"><div><p class="eyebrow">RECENT READINGS</p><h2>ประวัติมิเตอร์</h2></div></div>
          <div class="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>วันที่บันทึก</th>
                  <th>ห้อง</th>
                  <th>เดือน</th>
                  <th>หน่วยน้ำ</th>
                  <th>หน่วยไฟฟ้า</th>
                  <th>ค่าน้ำ/ไฟโดยประมาณ</th>
                  <?php if ($user['role'] === 'Admin'): ?><th>จัดการ</th><?php endif; ?>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($meters as $meter): ?>
                  <tr>
                    <td><?= e(thai_date($meter['recordDate'])) ?></td>
                    <td><strong><?= e($meter['roomNumber']) ?></strong></td>
                    <td><?= e($meter['month']) ?></td>
                    <td><?= money($meter['waterUnit']) ?></td>
                    <td><?= money($meter['electricUnit']) ?></td>
                    <td><?= money(((float) $meter['waterUnit'] * WATER_RATE) + ((float) $meter['electricUnit'] * ELECTRIC_RATE)) ?> ฿</td>
                    <?php if ($user['role'] === 'Admin'): ?>
                      <td class="row-actions">
                        <button class="icon-button" type="button" onclick='openEditMeterModal(<?= e(json_encode($meter, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>)' aria-label="แก้ไขมิเตอร์" title="แก้ไขมิเตอร์">✎</button>
                        <form method="post" action="index.php" style="display:inline;">
                          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                          <input type="hidden" name="action" value="delete_meter">
                          <input type="hidden" name="meterId" value="<?= e($meter['meterId']) ?>">
                          <input type="hidden" name="return_page" value="meters">
                          <button class="icon-button danger-icon" type="submit" data-confirm="ยืนยันการลบข้อมูลมิเตอร์ห้อง <?= e($meter['roomNumber']) ?> เดือน <?= e($meter['month']) ?> หรือไม่?" aria-label="ลบมิเตอร์" title="ลบมิเตอร์">×</button>
                        </form>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php if (!$meters): ?><div class="empty-state compact"><strong>ยังไม่มีรายการมิเตอร์</strong></div><?php endif; ?>
          </div>
        </section>
        <?php if ($user['role'] === 'Admin'): ?>
          <dialog class="modal" id="meter-edit-modal">
            <form method="post" action="index.php" class="modal-form">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="save_meter">
              <input type="hidden" name="return_page" value="meters">
              <input type="hidden" name="meterId" id="edit-meter-id">
              <div class="modal-heading">
                <div><p class="eyebrow">EDIT METER RECORD</p><h2>แก้ไขข้อมูลมิเตอร์</h2></div>
                <button class="icon-button" type="button" data-modal-close aria-label="ปิด">×</button>
              </div>
              <label>ห้องพัก
                <select name="roomId" id="edit-meter-room" required>
                  <?php foreach ($allRooms as $room): ?>
                    <option value="<?= e($room['roomId']) ?>"><?= e($room['roomNumber']) ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label>เดือน/ปี (MM/YYYY)<input name="month" id="edit-meter-month" required maxlength="20"></label>
              <div class="form-row">
                <label>หน่วยน้ำ<input type="number" min="0" step="0.01" name="waterUnit" id="edit-meter-water" required></label>
                <label>หน่วยไฟฟ้า<input type="number" min="0" step="0.01" name="electricUnit" id="edit-meter-electric" required></label>
              </div>
              <p class="form-hint">หากรอบบิลนี้ออกใบแจ้งหนี้สถานะ "รอชำระ" แล้ว ระบบจะอัปเดตหน่วยน้ำ-ไฟในใบแจ้งหนี้ให้อัตโนมัติ</p>
              <div class="modal-actions">
                <button class="button secondary" type="button" data-modal-close>ยกเลิก</button>
                <button class="button primary" type="submit">บันทึกการแก้ไข</button>
              </div>
            </form>
          </dialog>
          <script>
          function openEditMeterModal(meter) {
            document.getElementById('edit-meter-id').value = meter.meterId;
            document.getElementById('edit-meter-room').value = meter.roomId;
            document.getElementById('edit-meter-month').value = meter.month;
            document.getElementById('edit-meter-water').value = meter.waterUnit;
            document.getElementById('edit-meter-electric').value = meter.electricUnit;
            document.getElementById('meter-edit-modal').showModal();
          }
          </script>
        <?php endif; ?>
      <?php elseif ($page === 'payments'): ?>
        <?php require __DIR__ . '/payments.php'; ?>
      <?php elseif ($page === 'repairs'): ?>
        <?php if ($user['role'] === 'Tenant'): $statement = db()->prepare('SELECT rp.*, r.roomNumber FROM Repair rp JOIN Room r ON r.roomId = rp.roomId WHERE rp.userId = ? ORDER BY rp.repairDate DESC'); $statement->execute([$user['userId']]); $repairs = $statement->fetchAll(); $repairRooms = $tenantContract ? [['roomId' => $tenantContract['roomId'], 'roomNumber' => $tenantContract['roomNumber']]] : []; else: $query = "SELECT rp.*, u.name, r.roomNumber, tech.name AS technicianName FROM Repair rp JOIN `User` u ON u.userId = rp.userId JOIN Room r ON r.roomId = rp.roomId LEFT JOIN `User` tech ON tech.userId = rp.maintenanceUserId"; if ($user['role'] === 'Technician') { $statement = db()->prepare($query . ' WHERE rp.maintenanceUserId = ? ORDER BY rp.repairDate DESC'); $statement->execute([$user['userId']]); $repairs = $statement->fetchAll(); } else { $repairs = db()->query($query . ' ORDER BY rp.repairDate DESC')->fetchAll(); } $repairRooms = []; endif; $technicians = $user['role'] === 'Admin' ? db()->query("SELECT userId, name FROM `User` WHERE role = 'Technician' ORDER BY name")->fetchAll() : []; ?>
        <section class="page-heading"><div><p class="eyebrow">MAINTENANCE DESK</p><h1>งานซ่อม</h1><p class="muted">แจ้งปัญหา มอบหมายช่าง และติดตามความคืบหน้าการซ่อม</p></div></section>
        <?php if ($user['role'] === 'Tenant'): ?><section class="panel form-panel"><div class="panel-heading"><div><p class="eyebrow">NEW REQUEST</p><h2>ส่งคำร้องแจ้งซ่อม</h2></div></div><?php if ($repairRooms): ?><form method="post" action="index.php" enctype="multipart/form-data" class="inline-form repair-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_repair"><input type="hidden" name="return_page" value="repairs"><input type="hidden" name="roomId" value="<?= e($repairRooms[0]['roomId']) ?>"><label>ห้องพัก<input value="<?= e($repairRooms[0]['roomNumber']) ?>" disabled></label><label class="wide">รายละเอียดปัญหา<textarea name="detail" maxlength="500" required placeholder="อธิบายปัญหาที่พบ"></textarea></label><label>แนบรูปภาพ<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label><button class="button primary" type="submit">ส่งคำร้อง</button></form><?php else: ?><div class="empty-state compact"><strong>ต้องมีสัญญาเช่าที่ใช้งานก่อนแจ้งซ่อม</strong></div><?php endif; ?></section><?php endif; ?>
        <section class="repair-grid"><?php foreach ($repairs as $repair): $costQuery = db()->prepare('SELECT SUM(amount) FROM RepairDetail WHERE repairId = ?'); $costQuery->execute([$repair['repairId']]); $costTotal = (float) $costQuery->fetchColumn(); ?><article class="panel repair-card"><div class="repair-card-top"><span class="status-pill <?= $repair['repairStatus'] === 'ซ่อมเสร็จแล้ว' ? 'available' : 'pending' ?>"><?= e($repair['repairStatus']) ?></span><span class="mono muted"><?= e($repair['repairId']) ?></span></div><h2><?= e(mb_strimwidth($repair['detail'], 0, 90, '...', 'UTF-8')) ?></h2><p class="muted"><?= e($repair['name'] ?? $user['name']) ?> · ห้อง <?= e($repair['roomNumber'] ?? '') ?> · <?= e(thai_date($repair['repairDate'])) ?></p><?php if (!empty($repair['image'])): ?><a class="text-link" href="file.php?repair=<?= e($repair['repairId']) ?>" target="_blank" rel="noopener">ดูรูปประกอบ ↗</a><?php endif; ?><?php if (!empty($repair['technicianName'])): ?><p class="repair-assignee">ช่างผู้รับผิดชอบ <strong><?= e($repair['technicianName']) ?></strong></p><?php endif; ?><?php if ($costTotal > 0): ?><p class="repair-assignee">ค่าใช้จ่ายที่บันทึก <strong><?= money($costTotal) ?> ฿</strong></p><?php endif; ?>
          <?php if ($user['role'] === 'Admin' && empty($repair['maintenanceUserId'])): ?><form method="post" action="index.php" class="repair-controls"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="assign_repair"><input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>"><input type="hidden" name="return_page" value="repairs"><select name="maintenanceUserId" required><option value="">เลือกช่างซ่อม</option><?php foreach ($technicians as $technician): ?><option value="<?= e($technician['userId']) ?>"><?= e($technician['name']) ?></option><?php endforeach; ?></select><button class="button tiny primary" type="submit">มอบหมายช่าง</button></form><?php elseif ($user['role'] === 'Admin' && !empty($repair['maintenanceUserId'])): ?><p class="repair-assignee">มอบหมายแล้ว: <strong><?= e($repair['technicianName'] ?? 'ช่างซ่อม') ?></strong></p><?php endif; ?>
          <?php if (!empty($repair['workImage'])): ?><a class="text-link" href="file.php?work=<?= e($repair['repairId']) ?>" target="_blank" rel="noopener">ดูรูปก่อนเริ่มงาน ↗</a><?php endif; ?>
          <?php if (!empty($repair['quoteAmount'])): ?><p class="repair-quote-summary"><strong>ราคาเสนอ <?= money($repair['quoteAmount']) ?> ฿</strong><span><?= e($repair['quoteNote']) ?></span></p><?php endif; ?>
          <?php if (!empty($repair['repairResult'])): ?><p class="repair-assignee">ผลการซ่อม <strong><?= e($repair['repairResult']) ?></strong></p><?php endif; ?><?php if (!empty($repair['completionImage'])): ?><a class="text-link" href="file.php?after=<?= e($repair['repairId']) ?>" target="_blank" rel="noopener">ดูรูปหลังซ่อม ↗</a><?php endif; ?>
          <?php if ($user['role'] === 'Technician' && in_array($repair['repairStatus'], ['มอบหมายแล้ว', 'รอเสนอราคา', 'แก้ไขราคา'], true)): ?>
            <form method="post" action="index.php" class="repair-quote-form">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="submit_repair_quote">
              <input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>">
              <input type="hidden" name="return_page" value="repairs">
              <label>ราคาเสนอ (บาท)<input type="number" name="quoteAmount" min="0.01" step="0.01" value="<?= e((string) ($repair['quoteAmount'] ?? '')) ?>" required></label>
              <label>รายละเอียดใบเสนอราคา<textarea name="quoteNote" maxlength="500" rows="2" required placeholder="ระบุค่าแรง อุปกรณ์ หรือรายละเอียดที่เกี่ยวข้อง"><?= e($repair['quoteNote'] ?? '') ?></textarea></label>
              <button class="button tiny primary" type="submit">ส่งราคาให้แอดมินอนุมัติ</button>
            </form>
          <?php elseif ($user['role'] === 'Technician' && $repair['repairStatus'] === 'รออนุมัติราคา'): ?>
            <p class="repair-flow-note">ส่งราคาแล้ว กำลังรอแอดมินอนุมัติ ห้ามเริ่มงานก่อนอนุมัติ</p>
          <?php endif; ?>
          <?php if ($user['role'] === 'Staff' && in_array($repair['repairStatus'], ['รอตรวจสอบ', 'รอรับเรื่อง'], true)): ?><form method="post" action="index.php" class="repair-controls"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="forward_repair"><input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>"><input type="hidden" name="return_page" value="repairs"><button class="button tiny primary" type="submit">ส่งต่อให้ผู้ดูแล</button></form><?php endif; ?>
          <?php if ($user['role'] === 'Admin' && $repair['repairStatus'] === 'รออนุมัติราคา'): ?>
            <form method="post" action="index.php" class="repair-controls">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>">
              <input type="hidden" name="return_page" value="repairs">
              <button class="button tiny success" name="action" value="approve_repair_quote" type="submit">อนุมัติราคา</button>
              <button class="button tiny danger" name="action" value="reject_repair_quote" type="submit">ขอให้แก้ราคา</button>
            </form>
          <?php endif; ?>
          <?php if ($user['role'] === 'Admin' && $repair['repairStatus'] === 'รออนุมัติค่าใช้จ่าย'): ?><form method="post" action="index.php" class="repair-controls"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>"><input type="hidden" name="return_page" value="repairs"><button class="button tiny success" name="action" value="approve_repair_cost" type="submit">อนุมัติค่าใช้จ่ายจริง</button><button class="button tiny danger" name="action" value="reject_repair_cost" type="submit">ส่งกลับแก้ไข</button></form><?php endif; ?>
          <?php if ($user['role'] === 'Technician' && $repair['repairStatus'] === 'รอเริ่มงาน'): ?>
            <form method="post" action="index.php" enctype="multipart/form-data" class="repair-start-form">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="start_repair">
              <input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>">
              <input type="hidden" name="return_page" value="repairs">
              <label>แนบรูปก่อนเริ่มงาน<input type="file" name="workImage" accept="image/jpeg,image/png,image/webp" required></label>
              <button class="button tiny primary" type="submit">เริ่มทำงาน</button>
            </form>
          <?php endif; ?>
          <?php if ($user['role'] === 'Technician' && in_array($repair['repairStatus'], ['กำลังซ่อม', 'รอแก้ไขค่าใช้จ่าย'], true)): ?>
            <?php if ($repair['repairStatus'] === 'กำลังซ่อม'): ?>
            <p class="repair-flow-note">สถานะ: กำลังซ่อม</p>
            <form method="post" action="index.php" enctype="multipart/form-data" class="repair-result-form">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_repair"><input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>"><input type="hidden" name="repairStatus" value="<?= e($repair['repairStatus']) ?>"><input type="hidden" name="return_page" value="repairs">
              <label>ผลการซ่อม<textarea name="repairResult" maxlength="2000" rows="2" required placeholder="บันทึกสิ่งที่ดำเนินการ"><?= e($repair['repairResult'] ?? '') ?></textarea></label>
              <label>รูปหลังซ่อม<input type="file" name="completionImage" accept="image/jpeg,image/png,image/webp"></label>
              <button class="button tiny secondary" type="submit">บันทึกผลและปิดงาน</button>
            </form>
            <?php endif; ?>
            <?php if ($costTotal === 0.0 || $repair['repairStatus'] === 'รอแก้ไขค่าใช้จ่าย'): ?>
              <form method="post" action="index.php" class="repair-controls cost-controls">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_repair_cost"><input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>"><input type="hidden" name="return_page" value="repairs">
                <select name="costTypeId" required><option value="">เลือกประเภทค่าใช้จ่าย</option><?php foreach (db()->query('SELECT costTypeId, costTypeName FROM CostType ORDER BY costTypeId')->fetchAll() as $costType): ?><option value="<?= e($costType['costTypeId']) ?>"><?= e($costType['costTypeName']) ?></option><?php endforeach; ?></select>
                <input name="equipment" required maxlength="100" placeholder="รายการอุปกรณ์/ค่าแรง"><input type="number" name="amount" min="0" step="0.01" required placeholder="จำนวนเงิน">
                <button class="button tiny secondary" type="submit">บันทึกค่าใช้จ่าย</button>
              </form>
            <?php else: ?>
              <p class="repair-assignee">ค่าใช้จ่ายจริงได้รับการตรวจสอบแล้ว</p>
            <?php endif; ?>
          <?php endif; ?>
          <?php if ($user['role'] === 'Staff' && $repair['repairStatus'] === 'รอตรวจสอบค่าใช้จ่าย'): ?><form method="post" action="index.php" class="repair-controls"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="review_repair_cost"><input type="hidden" name="repairId" value="<?= e($repair['repairId']) ?>"><input type="hidden" name="return_page" value="repairs"><button class="button tiny primary" type="submit">ส่งให้ผู้ดูแลพิจารณา</button></form><?php endif; ?>
        </article><?php endforeach; ?></section><?php if (!$repairs): ?><div class="panel empty-state"><span>⌕</span><strong>ไม่พบรายการแจ้งซ่อม</strong><small>รายการใหม่จะแสดงที่นี่</small></div><?php endif; ?>
      <?php elseif ($page === 'news'): ?>
        <?php $news = db()->query('SELECT * FROM News ORDER BY publishDate DESC')->fetchAll(); ?>
        <section class="page-heading"><div><p class="eyebrow">NOTICE BOARD</p><h1>ข่าวสารและประกาศ</h1><p class="muted">ติดตามประกาศและข่าวสารจากหอพัก</p></div><?php if ($user['role'] === 'Admin'): ?><button class="button primary" type="button" data-modal-open="news-modal">＋ เพิ่มประกาศ</button><?php endif; ?></section>
        <section class="news-list"><?php foreach ($news as $item): ?><article class="panel news-card"><button class="news-card-open" type="button" data-news-preview="<?= e(json_encode($item, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>"><span class="news-card-date"><strong><?= e(date('d', strtotime($item['publishDate']))) ?></strong><span><?= e(thai_month_year($item['publishDate'])) ?></span></span><span class="news-card-body"><strong class="news-card-title"><?= e($item['title']) ?></strong><span class="news-card-summary"><?= e(mb_strimwidth($item['detail'], 0, 180, '...', 'UTF-8')) ?></span><?php if (!empty($item['image'])): ?><small class="news-image-hint">แตะเพื่ออ่านรายละเอียดและดูรูปภาพ</small><?php endif; ?></span><span class="news-open" aria-hidden="true">↗</span></button><?php if ($user['role'] === 'Admin'): ?><button class="icon-button" type="button" data-edit-news data-news="<?= e(json_encode($item, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>" aria-label="แก้ไขประกาศ">✎</button><form method="post" action="index.php"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_news"><input type="hidden" name="newsId" value="<?= e($item['newsId']) ?>"><input type="hidden" name="return_page" value="news"><button class="icon-button danger-icon" type="submit" data-confirm="ลบประกาศนี้หรือไม่?" aria-label="ลบประกาศ">×</button></form><?php endif; ?></article><?php endforeach; ?><?php if (!$news): ?><div class="panel empty-state"><span>▤</span><strong>ยังไม่มีประกาศ</strong><small>ประกาศใหม่จะแสดงที่หน้านี้</small></div><?php endif; ?></section>
        <?php if ($user['role'] === 'Admin'): ?><dialog class="modal" id="news-modal"><form method="post" action="index.php" enctype="multipart/form-data" class="modal-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_news"><input type="hidden" name="newsId"><input type="hidden" name="return_page" value="news"><div class="modal-heading"><div><p class="eyebrow">NOTICE BOARD</p><h2>เพิ่มประกาศ</h2></div><button class="icon-button" type="button" data-modal-close>×</button></div><label>หัวข้อ<input name="title" maxlength="200" required></label><label>รายละเอียด<textarea name="detail" maxlength="1000" required rows="5"></textarea></label><label>รูปประกาศ<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label><div class="modal-actions"><button class="button secondary" type="button" data-modal-close>ยกเลิก</button><button class="button primary" type="submit">เผยแพร่</button></div></form></dialog><?php endif; ?>
      <?php elseif ($page === 'reports'): ?>
        <?php
        $income = (float) db()->query("SELECT COALESCE(SUM(amount), 0) FROM Payment WHERE status = 'อนุมัติ' AND DATE_FORMAT(paymentDate, '%Y-%m') = DATE_FORMAT(CURRENT_DATE(), '%Y-%m')")->fetchColumn();
        $due = db()->query("SELECT r.roomNumber, u.name, r.rentalPrice FROM Contract c JOIN Room r ON r.roomId = c.roomId JOIN `User` u ON u.userId = c.userId WHERE c.status = 'ใช้งานอยู่' ORDER BY r.roomNumber")->fetchAll();
        $balances = db()->query("SELECT r.roomNumber, u.name,
            COALESCE((SELECT SUM(i.rentAmount + i.waterUnit * i.waterRate + i.electricUnit * i.electricRate) FROM Invoice i WHERE i.contractId = c.contractId AND i.status = 'รอชำระ'), 0)
            + COALESCE((SELECT SUM(f.amount) FROM Fine f WHERE f.contractId = c.contractId AND f.status = 'รอชำระ'), 0) AS balance
            FROM Contract c JOIN Room r ON r.roomId = c.roomId JOIN `User` u ON u.userId = c.userId
            WHERE c.status = 'ใช้งานอยู่' HAVING balance > 0 ORDER BY r.roomNumber")->fetchAll();
        $reportRepairs = db()->query('SELECT repairStatus, COUNT(*) AS total FROM Repair GROUP BY repairStatus ORDER BY total DESC')->fetchAll();
        $recentRepairs = db()->query("SELECT rp.repairDate, rp.repairStatus, rp.detail, r.roomNumber, u.name
            FROM Repair rp JOIN Room r ON r.roomId = rp.roomId JOIN `User` u ON u.userId = rp.userId
            WHERE rp.repairDate >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 DAY)
            ORDER BY rp.repairDate DESC, rp.repairId DESC")->fetchAll();
        $todayRepairs = db()->query("SELECT rp.repairDate, rp.repairStatus, rp.detail, r.roomNumber, u.name
            FROM Repair rp JOIN Room r ON r.roomId = rp.roomId JOIN `User` u ON u.userId = rp.userId
            WHERE rp.repairDate = CURRENT_DATE()
            ORDER BY rp.repairId DESC")->fetchAll();
        $roomSummary = db()->query('SELECT roomStatus, COUNT(*) AS total FROM Room GROUP BY roomStatus')->fetchAll();
        ?>
        <section class="page-heading"><div><p class="eyebrow">OPERATIONS REPORT</p><h1>รายงานสรุป</h1><p class="muted">ข้อมูลภาพรวมรายรับ ห้องพัก ยอดค้าง และงานซ่อม</p></div><span class="period-chip">เดือนนี้ · <?= e(date('m/') . (date('Y') + 543)) ?></span></section>
        <section class="metric-grid"><article class="metric-card"><div class="metric-top"><span>รายรับที่อนุมัติเดือนนี้</span><span class="metric-icon mint">฿</span></div><strong><?= money($income) ?> ฿</strong><small>รวมรายการชำระที่อนุมัติแล้ว</small></article><article class="metric-card"><div class="metric-top"><span>ห้องที่มีสัญญาใช้งาน</span><span class="metric-icon blue">♙</span></div><strong><?= count($due) ?></strong><small>ผู้เช่าปัจจุบัน</small></article><article class="metric-card"><div class="metric-top"><span>ยอดค้างชำระรวม</span><span class="metric-icon orange">฿</span></div><strong><?= money(array_sum(array_column($balances, 'balance'))) ?> ฿</strong><small><?= count($balances) ?> ห้องมีรายการค้าง</small></article><article class="metric-card"><div class="metric-top"><span>รายการแจ้งซ่อม</span><span class="metric-icon orange">⌕</span></div><strong><?= array_sum(array_column($reportRepairs, 'total')) ?></strong><small>รายการทั้งหมด</small></article><article class="metric-card"><div class="metric-top"><span>ห้องพักทั้งหมด</span><span class="metric-icon blue">⌂</span></div><strong><?= array_sum(array_column($roomSummary, 'total')) ?></strong><small>ทุกสถานะห้อง</small></article></section>
        <section class="dashboard-grid"><article class="panel"><div class="panel-heading"><div><p class="eyebrow">ROOM STATUS</p><h2>สถานะห้องพัก</h2></div></div><?php foreach ($roomSummary as $status): ?><div class="summary-row"><span><?= e($status['roomStatus']) ?></span><strong><?= e((string) $status['total']) ?> ห้อง</strong></div><?php endforeach; ?></article><article class="panel"><div class="panel-heading"><div><p class="eyebrow">REPAIR STATUS</p><h2>สถานะงานซ่อม</h2></div></div><?php foreach ($reportRepairs as $status): ?><div class="summary-row"><span><?= e($status['repairStatus']) ?></span><strong><?= e((string) $status['total']) ?> งาน</strong></div><?php endforeach; ?></article></section>
        <section class="panel table-panel"><div class="panel-heading" style="padding: 20px 24px 12px;"><div><p class="eyebrow">OUTSTANDING BY ROOM</p><h2>ยอดค้างชำระรายห้อง</h2></div></div><div class="table-scroll"><table><thead><tr><th>ห้อง</th><th>ผู้เช่า</th><th>ยอดค้างชำระ</th></tr></thead><tbody><?php foreach ($balances as $balance): ?><tr><td><?= e($balance['roomNumber']) ?></td><td><?= e($balance['name']) ?></td><td><strong><?= money($balance['balance']) ?> ฿</strong></td></tr><?php endforeach; ?></tbody></table><?php if (!$balances): ?><div class="empty-state compact"><strong>ไม่มีรายการค้างชำระ</strong></div><?php endif; ?></div></section>
        <section class="panel table-panel"><div class="panel-heading" style="padding: 20px 24px 12px;"><div><p class="eyebrow">REPAIR REQUESTS · TODAY</p><h2>รายการแจ้งซ่อมประจำวัน</h2></div><span class="panel-caption"><?= count($todayRepairs) ?> รายการ</span></div><div class="table-scroll"><table><thead><tr><th>วันที่</th><th>ห้อง</th><th>ผู้แจ้ง</th><th>รายละเอียด</th><th>สถานะ</th></tr></thead><tbody><?php foreach ($todayRepairs as $repair): ?><tr><td><?= e(thai_date($repair['repairDate'])) ?></td><td><?= e($repair['roomNumber']) ?></td><td><?= e($repair['name']) ?></td><td><?= e(mb_strimwidth($repair['detail'], 0, 100, '...', 'UTF-8')) ?></td><td><?= e($repair['repairStatus']) ?></td></tr><?php endforeach; ?></tbody></table><?php if (!$todayRepairs): ?><div class="empty-state compact"><strong>ไม่มีรายการแจ้งซ่อมวันนี้</strong></div><?php endif; ?></div></section>
        <section class="panel table-panel"><div class="panel-heading" style="padding: 20px 24px 12px;"><div><p class="eyebrow">REPAIR REQUESTS · LAST 7 DAYS</p><h2>รายการแจ้งซ่อมประจำสัปดาห์</h2></div><span class="panel-caption"><?= count($recentRepairs) ?> รายการ</span></div><div class="table-scroll"><table><thead><tr><th>วันที่</th><th>ห้อง</th><th>ผู้แจ้ง</th><th>รายละเอียด</th><th>สถานะ</th></tr></thead><tbody><?php foreach ($recentRepairs as $repair): ?><tr><td><?= e(thai_date($repair['repairDate'])) ?></td><td><?= e($repair['roomNumber']) ?></td><td><?= e($repair['name']) ?></td><td><?= e(mb_strimwidth($repair['detail'], 0, 100, '...', 'UTF-8')) ?></td><td><?= e($repair['repairStatus']) ?></td></tr><?php endforeach; ?></tbody></table><?php if (!$recentRepairs): ?><div class="empty-state compact"><strong>ไม่มีรายการแจ้งซ่อมใน 7 วันที่ผ่านมา</strong></div><?php endif; ?></div></section>
        <section class="panel table-panel"><div class="panel-heading" style="padding: 20px 24px 12px;"><div><p class="eyebrow">ACTIVE LEASES</p><h2>สัญญาเช่าที่ใช้งานอยู่</h2></div></div><div class="table-scroll"><table><thead><tr><th>ห้อง</th><th>ผู้เช่า</th><th>ค่าเช่าต่อเดือน</th></tr></thead><tbody><?php foreach ($due as $lease): ?><tr><td><?= e($lease['roomNumber']) ?></td><td><?= e($lease['name']) ?></td><td><?= money($lease['rentalPrice']) ?> ฿</td></tr><?php endforeach; ?></tbody></table></div></section>
      <?php elseif ($page === 'help'): ?>
        <?php $support = db()->query("SELECT name, email, phone FROM `User` WHERE role = 'Admin' ORDER BY name LIMIT 1")->fetch(); ?>
        <section class="page-heading"><div><p class="eyebrow">HELP & SUPPORT</p><h1>ศูนย์ช่วยเหลือ</h1><p class="muted">คำแนะนำการใช้งานและช่องทางติดต่อผู้ดูแลหอพัก</p></div></section>
        <section class="help-grid">
          <article class="panel help-card"><span class="help-card-icon">⌂</span><h2>การใช้งานระบบ</h2><ul><li>อัปเดตชื่อ เบอร์โทร อีเมล หรือรหัสผ่านได้ที่เมนู “ข้อมูลส่วนตัว”</li><li>ผู้เช่าดูรายละเอียดสัญญา ส่งหลักฐานชำระเงิน และติดตามงานซ่อมได้จากเมนูของตน</li><li>แตะรายการในกระดานข่าวเพื่ออ่านรายละเอียดและขยายดูรูปประกาศ</li><li>กด “ดูสลิป” เพื่อเปิดหลักฐานในหน้าต่าง และใช้ปุ่มปิดเพื่อกลับสู่รายการ</li></ul></article>
          <article class="panel help-card"><span class="help-card-icon">☎</span><h2>ติดต่อผู้ดูแลหอพัก</h2><?php if ($support): ?><p>ผู้ดูแล: <strong><?= e($support['name']) ?></strong></p><a class="support-link" href="mailto:<?= e($support['email']) ?>?subject=<?= rawurlencode('สอบถามการใช้งานระบบฟ้าใสเพลส') ?>">ส่งอีเมล <?= e($support['email']) ?></a><a class="support-link" href="tel:<?= e($support['phone']) ?>">โทร <?= e($support['phone']) ?></a><?php else: ?><p class="muted">ยังไม่มีข้อมูลช่องทางติดต่อผู้ดูแล กรุณาติดต่อผู้ดูแลหอพักโดยตรง</p><?php endif; ?></article>
        </section>
      <?php elseif ($page === 'profile'): ?>
        <?php $profileStatement = db()->prepare('SELECT userId, username, name, phone, email, role FROM `User` WHERE userId = ?'); $profileStatement->execute([$user['userId']]); $profile = $profileStatement->fetch(); ?>
        <section class="page-heading"><div><p class="eyebrow">ACCOUNT SETTINGS</p><h1>ข้อมูลส่วนตัว</h1><p class="muted">บัญชีและข้อมูลติดต่อของคุณ</p></div></section>
        <section class="panel profile-panel"><div class="profile-avatar"><?= e(mb_substr($profile['name'], 0, 1, 'UTF-8')) ?></div><div class="profile-details"><span class="status-pill available"><?= e($profile['role']) ?></span><h2><?= e($profile['name']) ?></h2><form method="post" action="index.php" class="profile-form"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_profile"><input type="hidden" name="return_page" value="profile"><label>ชื่อ-นามสกุล<input name="name" value="<?= e($profile['name']) ?>" required maxlength="100"></label><div class="form-row"><label>เบอร์โทรศัพท์<input name="phone" value="<?= e($profile['phone']) ?>" required pattern="[0-9]{10}" maxlength="10"></label><label>อีเมล<input type="email" name="email" value="<?= e($profile['email']) ?>" required maxlength="100"></label></div><label>เปลี่ยนรหัสผ่าน <small>(เว้นว่างหากไม่ต้องการเปลี่ยน)</small><input type="password" name="password" minlength="10" autocomplete="new-password"></label><p class="profile-username">Username <strong><?= e($profile['username']) ?></strong> · รหัส <span class="mono"><?= e($profile['userId']) ?></span></p><button class="button primary" type="submit">บันทึกข้อมูล</button></form></div></section>
      <?php endif; ?>
    </div>
  </main>
</div>

<dialog class="modal image-preview-modal" id="image-preview-modal"><div class="preview-modal-content"><div class="modal-heading"><h2>หลักฐานการชำระเงิน</h2><button class="icon-button" type="button" data-modal-close aria-label="ปิด">×</button></div><img alt="รูปภาพ"><button class="button secondary" type="button" data-modal-close>ปิดหน้าต่าง</button></div></dialog>
<dialog class="modal news-preview-modal" id="news-preview-modal"><div class="preview-modal-content"><div class="modal-heading"><h2 data-news-title></h2><button class="icon-button" type="button" data-modal-close aria-label="ปิด">×</button></div><img data-news-image alt="รูปประกอบประกาศ" hidden><p data-news-detail></p><button class="button secondary" type="button" data-modal-close>ปิดหน้าต่าง</button></div></dialog>

<!-- Modal ยืนยันการออกจากระบบ -->
<dialog class="modal logout-confirm-modal" id="logout-confirm-modal" onclick="if(event.target === this) this.close()">
  <div class="logout-modal-box">
    <div class="logout-modal-icon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
    </div>
    <h3>ยืนยันการออกจากระบบ</h3>
    <p>คุณต้องการออกจากระบบหอพักฟ้าใสเพลสใช่หรือไม่?<br><small>หากออกจากระบบแล้ว คุณจะต้องเข้าสู่ระบบใหม่อีกครั้ง</small></p>
    <div class="logout-modal-actions">
      <button type="button" class="button secondary" onclick="document.getElementById('logout-confirm-modal').close()">ยกเลิก</button>
      <button type="button" class="button logout-confirm-btn" onclick="document.getElementById('logout-form').submit()">ยืนยันออกจากระบบ</button>
    </div>
  </div>
</dialog>

<!-- Modal ยืนยันการทำรายการ (แทน Browser Confirm แบบเก่า) -->
<dialog class="modal logout-confirm-modal" id="action-confirm-modal" onclick="if(event.target === this) this.close()">
  <div class="logout-modal-box">
    <div class="logout-modal-icon" id="action-confirm-icon" aria-hidden="true" style="background: rgba(59, 130, 246, 0.12); color: #2563eb;">
      <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="8" x2="12" y2="12"/>
        <line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
    </div>
    <h3 id="action-confirm-title">ยืนยันการทำรายการ</h3>
    <p id="action-confirm-message" style="margin-bottom: 20px;">คุณต้องการดำเนินการนี้ใช่หรือไม่?</p>
    <div class="logout-modal-actions">
      <button type="button" class="button secondary" onclick="document.getElementById('action-confirm-modal').close()">ยกเลิก</button>
      <button type="button" class="button primary" id="action-confirm-submit">ยืนยัน</button>
    </div>
  </div>
</dialog>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const formModals = document.querySelectorAll('dialog.modal:not(#logout-confirm-modal):not(#action-confirm-modal):not(#image-preview-modal):not(#news-preview-modal)');

  formModals.forEach((modal) => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        e.stopImmediatePropagation();
      }
    }, true);

    modal.addEventListener('cancel', (e) => {
      e.preventDefault();
    });
  });

  // แปลงปุ่มที่มี data-confirm ทั้งหมดให้ใช้ Pop-up Modal แทน window.confirm() และไม่เด้งซ้ำ
  const confirmModal = document.getElementById('action-confirm-modal');
  const confirmTitle = document.getElementById('action-confirm-title');
  const confirmMessage = document.getElementById('action-confirm-message');
  const confirmSubmitBtn = document.getElementById('action-confirm-submit');
  const confirmIcon = document.getElementById('action-confirm-icon');
  let pendingConfirmTarget = null;

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-confirm]');
    if (!btn) return;

    e.preventDefault();
    e.stopImmediatePropagation();

    pendingConfirmTarget = btn;
    const msg = btn.getAttribute('data-confirm') || 'คุณต้องการดำเนินการนี้ใช่หรือไม่?';
    const isDanger = btn.classList.contains('danger') || btn.classList.contains('danger-icon') || msg.includes('ลบ') || msg.includes('ปฏิเสธ') || msg.includes('สิ้นสุด');

    confirmTitle.textContent = isDanger ? 'ยืนยันการดำเนินการ' : 'ยืนยันการทำรายการ';
    confirmMessage.textContent = msg;

    if (isDanger) {
      confirmIcon.style.background = 'rgba(239, 68, 68, 0.12)';
      confirmIcon.style.color = '#dc2626';
      confirmSubmitBtn.className = 'button danger';
      confirmSubmitBtn.textContent = 'ยืนยัน';
    } else {
      confirmIcon.style.background = 'rgba(16, 185, 129, 0.14)';
      confirmIcon.style.color = '#059669';
      confirmSubmitBtn.className = 'button success';
      confirmSubmitBtn.textContent = 'ยืนยันอนุมัติ';
    }

    confirmModal.showModal();
  }, true);

  confirmSubmitBtn.addEventListener('click', () => {
    confirmModal.close();
    if (pendingConfirmTarget) {
      const target = pendingConfirmTarget;
      pendingConfirmTarget = null;
      target.removeAttribute('data-confirm');
      if (target.form && typeof target.form.requestSubmit === 'function') {
        target.form.requestSubmit(target);
      } else {
        target.click();
      }
    }
  });
});

// เปิดดูสลิปใน Popup Modal ที่มีปุ่มปิด
document.addEventListener('click', (e) => {
  const slipLink = e.target.closest('a[href*="file.php?id="]');
  if (!slipLink) return;
  const modal = document.getElementById('image-preview-modal');
  const img = modal ? modal.querySelector('img') : null;
  if (modal && img) {
    e.preventDefault();
    const url = new URL(slipLink.href, window.location.href);
    url.searchParams.set('raw', '1');
    img.src = url.toString();
    modal.showModal();
  }
});
</script>

</body>
</html>